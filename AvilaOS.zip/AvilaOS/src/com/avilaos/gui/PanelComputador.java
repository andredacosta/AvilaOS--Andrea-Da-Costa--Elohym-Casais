package com.avilaos.gui;

import com.avilaos.model.PoliticaPlanificacion;
import javax.swing.*;
import java.awt.*;

/**
 * Panel visual que representa un nodo (Computador) del clúster
 * @author Elohym Casais
 */
public class PanelComputador extends JPanel {

    private static final long serialVersionUID = 1L;
    private final String idComputador;

    private JLabel lblProcesoEnCPU;
    private JLabel lblProgramCounter;
    private JLabel lblModoCPU;
    private JComboBox<PoliticaPlanificacion> comboPolitica;
    private JTextField txtQuantum;
    private JProgressBar barraRAM;

    private DefaultListModel<String> modelNuevos;
    private DefaultListModel<String> modelListos;
    private DefaultListModel<String> modelBloqueados;
    private DefaultListModel<String> modelTerminados;

    public PanelComputador(String idComputador, int capacidadRAMTotal) {
        this.idComputador = idComputador;

        setLayout(new BorderLayout(5, 5));
        setPreferredSize(new Dimension(500, 420));
        setMinimumSize(new Dimension(450, 380));

        setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0, 102, 204), 2),
                " Nodo: " + idComputador + " "
        ));

        inicializarComponentes(capacidadRAMTotal);
    }

    private void inicializarComponentes(int capacidadRAMTotal) {
        // PANEL NORTE: Ajustes y Creación Manual
        JPanel panelNorte = new JPanel();
        panelNorte.setLayout(new BoxLayout(panelNorte, BoxLayout.Y_AXIS));

        JPanel panelPolitica = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelPolitica.add(new JLabel("Política:"));

        // CORRECCIÓN: Usar .values() para cargar el arreglo completo del Enum
        comboPolitica = new JComboBox<>(PoliticaPlanificacion.values());
        panelPolitica.add(comboPolitica);

        panelPolitica.add(new JLabel("Quantum:"));
        txtQuantum = new JTextField("2", 3);
        panelPolitica.add(txtQuantum);
        panelNorte.add(panelPolitica);

        // Formulario manual
        JPanel panelCrearProceso = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
        panelCrearProceso.setBorder(BorderFactory.createTitledBorder("Crear Proceso Manual"));

        JTextField txtNombre = new JTextField("P1", 4);
        JTextField txtInstrucciones = new JTextField("5", 3);
        JTextField txtRAM = new JTextField("128", 3);
        JButton btnAgregar = new JButton("+ Agregar");

        btnAgregar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            String info = nombre + " | Inst:" + txtInstrucciones.getText() + " | RAM:" + txtRAM.getText() + "KB";
            modelNuevos.addElement(info);
        });

        panelCrearProceso.add(new JLabel("Nom:"));
        panelCrearProceso.add(txtNombre);
        panelCrearProceso.add(new JLabel("Inst:"));
        panelCrearProceso.add(txtInstrucciones);
        panelCrearProceso.add(new JLabel("RAM:"));
        panelCrearProceso.add(txtRAM);
        panelCrearProceso.add(btnAgregar);

        panelNorte.add(panelCrearProceso);
        add(panelNorte, BorderLayout.NORTH);

        // PANEL CENTRO: CPU y RAM
        JPanel panelCentro = new JPanel(new GridLayout(2, 1, 5, 5));

        JPanel panelCPU = new JPanel(new GridLayout(3, 1));
        panelCPU.setBorder(BorderFactory.createTitledBorder("Estado de CPU"));
        lblProcesoEnCPU = new JLabel("Proceso en CPU: [IDLE]");
        lblProgramCounter = new JLabel("Program Counter (PC): 0");
        lblModoCPU = new JLabel("Modo: USUARIO");
        panelCPU.add(lblProcesoEnCPU);
        panelCPU.add(lblProgramCounter);
        panelCPU.add(lblModoCPU);

        JPanel panelRAM = new JPanel(new BorderLayout());
        panelRAM.setBorder(BorderFactory.createTitledBorder("Ocupación RAM"));
        barraRAM = new JProgressBar(0, capacidadRAMTotal);
        barraRAM.setStringPainted(true);
        barraRAM.setValue(0);
        barraRAM.setString("0 / " + capacidadRAMTotal + " KB");
        panelRAM.add(barraRAM, BorderLayout.CENTER);

        panelCentro.add(panelCPU);
        panelCentro.add(panelRAM);
        add(panelCentro, BorderLayout.CENTER);

        // PANEL SUR: Colas de Procesos
        JPanel panelColas = new JPanel(new GridLayout(1, 4, 2, 2));
        panelColas.setPreferredSize(new Dimension(480, 130));
        panelColas.setBorder(BorderFactory.createTitledBorder("Colas de Estado"));

        modelNuevos = new DefaultListModel<>();
        modelListos = new DefaultListModel<>();
        modelBloqueados = new DefaultListModel<>();
        modelTerminados = new DefaultListModel<>();

        panelColas.add(crearPanelCola("Nuevos", new JList<>(modelNuevos)));
        panelColas.add(crearPanelCola("Listos", new JList<>(modelListos)));
        panelColas.add(crearPanelCola("Bloqueados", new JList<>(modelBloqueados)));
        panelColas.add(crearPanelCola("Terminados", new JList<>(modelTerminados)));

        add(panelColas, BorderLayout.SOUTH);
    }

    private JPanel crearPanelCola(String titulo, JList<String> lista) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        panel.add(new JScrollPane(lista), BorderLayout.CENTER);
        return panel;
    }

    public void agregarProcesoColaNuevo(String textoProceso) {
        modelNuevos.addElement(textoProceso);
    }
}