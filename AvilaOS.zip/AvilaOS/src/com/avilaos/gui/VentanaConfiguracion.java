package com.avilaos.gui;

import com.avilaos.config.ConfiguracionSistemaDTO;
import com.avilaos.config.GestorConfiguracion;
import javax.swing.*;
import java.awt.*;
import java.io.File;

public class VentanaConfiguracion extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField txtDuracionCiclo;
    private JTextField txtLatenciaRed;
    private JTextField txtNumComputadores;
    private JTextField txtCapacidadRAM;

    private final GestorConfiguracion gestorConfig;

    public VentanaConfiguracion() {
        this.gestorConfig = new GestorConfiguracion();

        setTitle("ÁvilaOS — Configuración Inicial del Sistema");
        setSize(480, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        construirFormulario();
        construirBotones();
    }

    private void construirFormulario() {
        JPanel panelForm = new JPanel(new GridLayout(4, 2, 10, 10));
        panelForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        panelForm.add(new JLabel("Duración del Ciclo (ms):"));
        txtDuracionCiclo = new JTextField("1000");
        panelForm.add(txtDuracionCiclo);

        panelForm.add(new JLabel("Latencia de Red (ciclos):"));
        txtLatenciaRed = new JTextField("2");
        panelForm.add(txtLatenciaRed);

        panelForm.add(new JLabel("Número de Computadores:"));
        txtNumComputadores = new JTextField("2");
        panelForm.add(txtNumComputadores);

        panelForm.add(new JLabel("RAM por Computador (KB):"));
        txtCapacidadRAM = new JTextField("1024");
        panelForm.add(txtCapacidadRAM);

        add(panelForm, BorderLayout.CENTER);
    }

    private void construirBotones() {
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        JButton btnIniciar = new JButton("Iniciar Simulación Manual");
        btnIniciar.addActionListener(e -> accionarIniciarSimulacion());

        panelBotones.add(btnIniciar);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void accionarIniciarSimulacion() {
        int numComputadores = getNumComputadores();
        int capacidadRAM = getCapacidadRAM();

        // Lanzar la VentanaPrincipal
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal vPrincipal = new VentanaPrincipal();
            vPrincipal.limpiarClustering();

            for (int i = 1; i <= numComputadores; i++) {
                PanelComputador panelPC = new PanelComputador("PC-" + i, capacidadRAM);
                vPrincipal.agregarPanelComputador(panelPC);
            }

            vPrincipal.setVisible(true);
        });

        this.dispose();
    }

    public int getNumComputadores() {
        try {
            return Integer.parseInt(txtNumComputadores.getText().trim());
        } catch (NumberFormatException e) {
            return 2;
        }
    }

    public int getCapacidadRAM() {
        try {
            return Integer.parseInt(txtCapacidadRAM.getText().trim());
        } catch (NumberFormatException e) {
            return 1024;
        }
    }
}