package com.avilaos.gui;

import com.avilaos.model.EventLogger;
import javax.swing.*;
import java.awt.*;

/**
 * Ventana Principal del Simulador ÁvilaOS.
 * Sincroniza el reloj global, el log de eventos, la visualización
 * del clúster de computadores y las gráficas de rendimiento.
 * 
 * @author Elohym Casais
 */
public class VentanaPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;

    // Componentes del Panel Superior
    private JLabel lblRelojGlobal;
    private JTextArea txtLogEventos;
    private JButton btnControlSimulacion;
    private JPanel panelBuffersGlobal;

    // Componentes del Panel Central
    private JPanel panelClustering;

    // Componentes del Panel Inferior (Métricas y Gráfica)
    private GraficaUtilizacionCPU panelGraficaCPU;
    private JLabel lblThroughput;
    private JLabel lblUtilizacionCPU;
    private JLabel lblTasaDeadlines;

    // Control del Hilo del Reloj / Simulación
    private Timer timerSimulacion;
    private long cicloActual = 0;
    private boolean enEjecucion = false;

    public VentanaPrincipal() {
        setTitle("ÁvilaOS — Simulador de Sistema Operativo Distribuido");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1366, 768);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        construirVistaSuperior();
        construirVistaCentral();
        construirVistaInferior();

        inicializarTimerSimulacion();
    }

    private void construirVistaSuperior() {
        JPanel panelSuperior = new JPanel(new BorderLayout(10, 5));
        panelSuperior.setBorder(BorderFactory.createTitledBorder("Control Global & Sincronización"));

        // Reloj Global y Botón de Inicio/Pausa
        JPanel panelHeader = new JPanel(new BorderLayout(10, 10));
        
        lblRelojGlobal = new JLabel("Reloj Global: Ciclo 0", SwingConstants.CENTER);
        lblRelojGlobal.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblRelojGlobal.setForeground(new Color(0, 102, 204));
        panelHeader.add(lblRelojGlobal, BorderLayout.CENTER);

        btnControlSimulacion = new JButton("▶ Iniciar Simulación");
        btnControlSimulacion.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnControlSimulacion.setBackground(new Color(40, 167, 69));
        btnControlSimulacion.setForeground(Color.WHITE);
        btnControlSimulacion.setFocusPainted(false);
        btnControlSimulacion.addActionListener(e -> alternarSimulacion());
        panelHeader.add(btnControlSimulacion, BorderLayout.EAST);

        panelSuperior.add(panelHeader, BorderLayout.NORTH);

        // Registro de Eventos del Sistema
        txtLogEventos = new JTextArea(4, 50);
        txtLogEventos.setEditable(false);
        txtLogEventos.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollLog = new JScrollPane(txtLogEventos);
        scrollLog.setBorder(BorderFactory.createTitledBorder("Registro de Eventos del Sistema"));
        panelSuperior.add(scrollLog, BorderLayout.CENTER);

        // Buffers compartidos / Semáforos
        panelBuffersGlobal = new JPanel();
        panelBuffersGlobal.setLayout(new BoxLayout(panelBuffersGlobal, BoxLayout.Y_AXIS));
        panelBuffersGlobal.setBorder(BorderFactory.createTitledBorder("Buffers Compartidos"));
        panelSuperior.add(panelBuffersGlobal, BorderLayout.EAST);

        add(panelSuperior, BorderLayout.NORTH);
    }

    private void construirVistaCentral() {
        // Panel contenedor con alineación horizontal para mostrar los computadores en paralelo
        panelClustering = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 15));

        JScrollPane scrollCluster = new JScrollPane(panelClustering);
        scrollCluster.setBorder(BorderFactory.createTitledBorder("Clúster de Computadores Simulados"));
        scrollCluster.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollCluster.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        add(scrollCluster, BorderLayout.CENTER);
    }

    private void construirVistaInferior() {
        JPanel panelInferior = new JPanel(new BorderLayout(10, 5));
        panelInferior.setPreferredSize(new Dimension(getWidth(), 190));
        panelInferior.setBorder(BorderFactory.createTitledBorder("Métricas de Rendimiento Global"));

        JPanel panelMetricasTexto = new JPanel(new GridLayout(3, 1, 5, 5));
        panelMetricasTexto.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblThroughput = new JLabel("Throughput: 0.00 proc/ciclo");
        lblUtilizacionCPU = new JLabel("Utilización Promedio CPU: 0.00%");
        lblTasaDeadlines = new JLabel("Cumplimiento Deadlines: 100.00%");

        lblThroughput.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblUtilizacionCPU.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTasaDeadlines.setFont(new Font("SansSerif", Font.BOLD, 12));

        panelMetricasTexto.add(lblThroughput);
        panelMetricasTexto.add(lblUtilizacionCPU);
        panelMetricasTexto.add(lblTasaDeadlines);

        panelInferior.add(panelMetricasTexto, BorderLayout.WEST);

        // Gráfica JFreeChart
        panelGraficaCPU = new GraficaUtilizacionCPU();
        panelInferior.add(panelGraficaCPU, BorderLayout.CENTER);

        add(panelInferior, BorderLayout.SOUTH);
    }

    // =========================================================================
    // LÓGICA DE CONTROL DEL RELOJ Y SIMULACIÓN
    // =========================================================================

    private void inicializarTimerSimulacion() {
        // Ejecuta un paso de reloj cada 1000 ms (1 segundo)
        timerSimulacion = new Timer(1000, e -> ejecutarPasoSimulacion());
    }

    private void alternarSimulacion() {
        if (enEjecucion) {
            timerSimulacion.stop();
            enEjecucion = false;
            btnControlSimulacion.setText("▶ Reanudar Simulación");
            btnControlSimulacion.setBackground(new Color(40, 167, 69));
        } else {
            timerSimulacion.start();
            enEjecucion = true;
            btnControlSimulacion.setText("⏸ Pausar Simulación");
            btnControlSimulacion.setBackground(new Color(220, 53, 69));
        }
    }

    private void ejecutarPasoSimulacion() {
        cicloActual++;
        lblRelojGlobal.setText("Reloj Global: Ciclo " + cicloActual);

        // Simulamos la recolección de métricas de CPU de los dos nodos
        double usoCPU_PC1 = Math.min(100.0, Math.random() * 40 + 50); // Carga entre 50% y 90%
        double usoCPU_PC2 = Math.min(100.0, Math.random() * 30 + 20); // Carga entre 20% y 50%
        double usoPromedio = (usoCPU_PC1 + usoCPU_PC2) / 2.0;

        // 1. Enviar puntos a la gráfica de JFreeChart para dibujar la curva
        panelGraficaCPU.agregarPunto(cicloActual, usoCPU_PC1, "PC-1");
        panelGraficaCPU.agregarPunto(cicloActual, usoCPU_PC2, "PC-2");

        // 2. Actualizar etiquetas de métricas
        lblThroughput.setText(String.format("Throughput: %.2f proc/ciclo", (cicloActual * 0.12)));
        lblUtilizacionCPU.setText(String.format("Utilización Promedio CPU: %.1f%%", usoPromedio));

        // 3. Refrescar log si existen eventos nuevos
        actualizarLog();
    }

    // =========================================================================
    // MÉTODOS PÚBLICOS DE INTEGRACIÓN DE LA GUI
    // =========================================================================

    public void limpiarClustering() {
        panelClustering.removeAll();
        panelClustering.revalidate();
        panelClustering.repaint();
    }

    public void agregarPanelComputador(PanelComputador panel) {
        panelClustering.add(panel);
        panelClustering.revalidate();
        panelClustering.repaint();
    }

    public void actualizarLog() {
        txtLogEventos.setText(EventLogger.getInstancia().getLogCompleto());
        txtLogEventos.setCaretPosition(txtLogEventos.getDocument().getLength());
    }

    public void actualizarReloj(long ciclo) {
        this.cicloActual = ciclo;
        lblRelojGlobal.setText("Reloj Global: Ciclo " + cicloActual);
    }
}